var $, Functions, Methods, PurchasesActions, _;

$ = require('jquery');

_ = require('underscore');

Methods = require('./Methods.coffee');

PurchasesActions = require('../../actions/PurchasesActions.js');

Functions = {
  filterByPrice: function(products_collection, values) {
    var tmp_filtered_сollection;
    return tmp_filtered_сollection = _.filter(products_collection, function(product) {
      return product.price >= values[0] && product.price <= values[1];
    });
  },
  filterByCategory: function(flat_products, products_collection) {
    var result_collection;
    return result_collection = _.filter(products_collection, function(product) {
      var function_name;
      return function_name = _.some(flat_products, function(cat_product) {
        return product.id === cat_product.id;
      });
    });
  },
  filterFlow: function(filter, initial_collection, categories) {
    var cat_catalogs, flat_category_products, result, result_by_cat, result_by_price, sorted_collection;
    console.log('start filter flow');
    console.log('filterFlow PurchasesStore filter: ', filter.filter_state);
    console.log('filterFlow PurchasesStore initial_collection: ', initial_collection);
    console.log('filterFlow PurchasesStore categories: ', categories);
    result_by_cat = [];
    result_by_price = [];
    if (filter.filter_state.category !== void 0 && filter.filter_state.category !== '') {
      cat_catalogs = Methods.getCatalogsFromCategories(categories, filter.filter_state.category);
      flat_category_products = Methods.convertCatalogsToFlatProducts(cat_catalogs);
      result_by_cat = flat_category_products;
    } else if (filter.filter_state.category === '') {
      result_by_cat = initial_collection;
    }
    if (filter.filter_state.price !== void 0) {
      result_by_price = this.filterByPrice(initial_collection, filter.filter_state.price);
    }
    result = Methods.unionProductCollections(result_by_price, result_by_cat);
    return sorted_collection = _.sortBy(result, function(product) {
      return product.price;
    });
  }
};

module.exports = Functions;
