var Dispatcher = require('flux').Dispatcher;

var PurchasesDispatcher = new Dispatcher();

module.exports = PurchasesDispatcher;
