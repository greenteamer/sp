var Dispatcher = require('flux').Dispatcher;

var FaqDispatcher = new Dispatcher();

module.exports = FaqDispatcher;
